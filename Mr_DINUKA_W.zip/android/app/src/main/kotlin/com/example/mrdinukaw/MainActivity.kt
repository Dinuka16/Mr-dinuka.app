package com.example.mrdinukaw

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
