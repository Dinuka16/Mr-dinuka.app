import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const InvisibleWhatsApp());
}

class InvisibleWhatsApp extends StatefulWidget {
  const InvisibleWhatsApp({super.key});

  @override
  State<InvisibleWhatsApp> createState() => _InvisibleWhatsAppState();
}

class _InvisibleWhatsAppState extends State<InvisibleWhatsApp> {
  bool _isDarkMode = true;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mr Dinuka W',
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        cardColor: Colors.white,
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF10B981), 
          secondary: Color(0xFF06B6D4),
          surface: Colors.white,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D16), // Deep AMOLED Black
        cardColor: const Color(0xFF111827),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF10B981),
          secondary: Color(0xFF06B6D4),
          surface: const Color(0xFF111827),
        ),
        useMaterial3: true,
      ),
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: MainNavigationScreen(
        isDarkMode: _isDarkMode,
        onThemeToggle: (value) => setState(() => _isDarkMode = value),
      ),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onThemeToggle;

  const MainNavigationScreen({
    super.key,
    required this.isDarkMode,
    required this.onThemeToggle,
  });

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final List<Map<String, String>> mockChats = [
    {"name": "Amma ❤️", "msg": "පුතා කෑවද?", "time": "11:30 AM", "unread": "2"},
    {"name": "Kasun (Uni)", "msg": "Machan assignment eka liwada?", "time": "10:45 AM", "unread": "0"},
    {"name": "Nimal Nishantha", "msg": "Sure boss, mama ewannam.", "time": "Yesterday", "unread": "1"},
  ];

  final List<Map<String, String>> mockStatuses = [
    {"name": "My Status", "time": "Tap to add status update", "isMe": "true"},
    {"name": "Dilshan", "time": "10 minutes ago", "isMe": "false"},
    {"name": "Sajith Perera", "time": "2 hours ago", "isMe": "false"},
  ];

  final List<Map<String, String>> mockContacts = [
    {"name": "Amesh Silva", "status": "Hey there! I am using this app."},
    {"name": "Bawantha Dewpura", "status": "Sleeping 😴"},
    {"name": "Chathura Rajapaksha", "status": "Urgent calls only"},
    {"name": "Dananjaya", "status": "At work"},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Mr Dinuka W',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        actions: [
          IconButton(
            onPressed: () => widget.onThemeToggle(!widget.isDarkMode),
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              transitionBuilder: (child, anim) => RotationTransition(turns: anim, child: child),
              child: widget.isDarkMode
                  ? const Icon(Icons.wb_sunny_rounded, key: ValueKey('light'), color: Colors.amber)
                  : const Icon(Icons.dark_mode_rounded, key: ValueKey('dark'), color: Colors.indigoAccent),
            ),
          ),
          const SizedBox(width: 8),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Theme.of(context).colorScheme.primary,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.5),
          tabs: const [
            Tab(text: 'CHATS'),
            Tab(text: 'STATUS'),
            Tab(text: 'CONTACTS'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildChatTab(),
          _buildStatusTab(),
          _buildContactsTab(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _tabController.animateTo(2),
        backgroundColor: Theme.of(context).colorScheme.primary,
        child: const Icon(Icons.message_rounded, color: Colors.white),
      ),
    );
  }

  Widget _buildChatTab() {
    return ListView.builder(
      itemCount: mockChats.length,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      itemBuilder: (context, index) {
        final chat = mockChats[index];
        return AnimatedContainer(
          duration: Duration(milliseconds: 300 + (index * 100)),
          curve: Curves.easeOutQuad,
          margin: const EdgeInsets.only(bottom: 12),
          child: Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: CircleAvatar(
                radius: 24,
                backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                child: Text(chat['name']![0], style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
              ),
              title: Text(chat['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(chat['msg']!),
              trailing: Text(chat['time']!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ChatDetailScreen(name: chat['name']!)),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatusTab() {
    return ListView.builder(
      itemCount: mockStatuses.length,
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, index) {
        final status = mockStatuses[index];
        bool isMe = status['isMe'] == 'true';
        return ListTile(
          leading: CircleAvatar(
            radius: 24,
            backgroundColor: isMe ? Colors.grey.withOpacity(0.3) : Theme.of(context).colorScheme.primary.withOpacity(0.3),
            child: Icon(isMe ? Icons.add_a_photo_rounded : Icons.person_rounded),
          ),
          title: Text(status['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(status['time']!),
        );
      },
    );
  }

  Widget _buildContactsTab() {
    return ListView.builder(
      itemCount: mockContacts.length,
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, index) {
        final contact = mockContacts[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
              child: Text(contact['name']![0]),
            ),
            title: Text(contact['name']!, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(contact['status']!),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ChatDetailScreen(name: contact['name']!)),
            ),
          ),
        );
      },
    );
  }
}

class ChatDetailScreen extends StatefulWidget {
  final String name;
  const ChatDetailScreen({super.key, required this.name});

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [
    {"text": "Hey! Are you online?", "isMe": false},
  ];

  static const platform = MethodChannel('com.example.invisiblechat/whatsapp');

  void _sendGhostMessage() async {
    if (_messageController.text.trim().isEmpty) return;
    final String textToSend = _messageController.text.trim();
    
    setState(() {
      _messages.add({"text": textToSend, "isMe": true});
      _messageController.clear();
    });

    try {
      await platform.invokeMethod('sendWhatsAppReply', {
        "contactName": widget.name,
        "messageText": textToSend,
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Ghost message processed background.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Text('👻 Ghost Mode Active', style: TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              padding: const EdgeInsets.all(16),
              itemBuilder: (context, index) {
                final msg = _messages[index];
                bool isMe = msg['isMe'];
                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: isMe ? Theme.of(context).colorScheme.primary : Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(msg['text'], style: TextStyle(color: isMe ? Colors.white : null)),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: "Type silently...",
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.send_rounded, color: Color(0xFF10B981)),
                  onPressed: _sendGhostMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}